using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;
using MDPlus.Core;

namespace MDPlus.Models
{
    public class AppSettings
    {
        private static readonly string SettingsFolder = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "MDPlus");

        private static readonly string SettingsFile = Path.Combine(SettingsFolder, "settings.json");

        [JsonConverter(typeof(JsonStringEnumConverter))]
        public ThemePreset Theme { get; set; } = ThemePreset.GitHubDark;

        public bool ShowMenuBar { get; set; } = false;
        public bool ShowToc { get; set; } = true;
        public bool ShowLineNumbers { get; set; } = true;
        public bool AutoReload { get; set; } = true;
        public bool WordWrap { get; set; } = true;
        public double WindowWidth { get; set; } = 1100;
        public double WindowHeight { get; set; } = 750;
        public bool WindowMaximized { get; set; } = false;
        public List<string> RecentFiles { get; set; } = new List<string>();
        public bool EnableLatexRendering { get; set; } = true;
        public bool EnableHtmlRendering { get; set; } = true;

        /// <summary>
        /// When true (default), launching MDPlus with a file when an instance is already running
        /// opens the file in a new tab of the existing window rather than spawning a new window.
        /// </summary>
        public bool OpenFilesInNewTab { get; set; } = true;

        /// <summary>
        /// Whether to automatically check for updates on startup (at most once every 24 hours).
        /// </summary>
        public bool CheckForUpdatesOnStartup { get; set; } = true;

        /// <summary>
        /// Timestamp in UTC when the last automated or manual update check was performed.
        /// </summary>
        public DateTime? LastUpdateCheckUtc { get; set; }

        /// <summary>
        /// Whether to restore previously open files on startup (default: true).
        /// If false, the application starts fresh without reopening previous files.
        /// </summary>
        public bool ResumeSession { get; set; } = true;

        [JsonIgnore]
        public bool StartFresh
        {
            get => !ResumeSession;
            set => ResumeSession = !value;
        }

        [JsonIgnore]
        public bool RestoreSession
        {
            get => ResumeSession;
            set => ResumeSession = value;
        }

        /// <summary>
        /// List of file paths that were open in tabs when the application last closed.
        /// </summary>
        public List<string> OpenFiles { get; set; } = new List<string>();

        /// <summary>
        /// The file path of the tab that was active when the application last closed.
        /// </summary>
        public string? ActiveFile { get; set; }

        /// <summary>
        /// Indicates whether a session has ever been saved by the application.
        /// </summary>
        public bool HasSavedSession { get; set; } = false;

        /// <summary>
        /// Tracks whether the first run experience has completed.
        /// </summary>
        public bool FirstRunCompleted { get; set; } = false;

        [JsonIgnore]
        public bool IsFirstRun => !FirstRunCompleted && (RecentFiles == null || RecentFiles.Count == 0) && (OpenFiles == null || OpenFiles.Count == 0);

        public void UpdateOpenFiles(IEnumerable<string> filePaths, string? activeFile = null)
        {
            OpenFiles.Clear();
            if (filePaths != null)
            {
                foreach (var path in filePaths)
                {
                    if (!string.IsNullOrWhiteSpace(path) && File.Exists(path))
                    {
                        string full = Path.GetFullPath(path);
                        if (!OpenFiles.Any(f => f.Equals(full, StringComparison.OrdinalIgnoreCase)))
                        {
                            OpenFiles.Add(full);
                        }
                    }
                }
            }
            ActiveFile = !string.IsNullOrWhiteSpace(activeFile) && File.Exists(activeFile)
                ? Path.GetFullPath(activeFile)
                : OpenFiles.Count > 0 ? OpenFiles[0] : null;
            HasSavedSession = true;
        }

        public void AddRecentFile(string path)
        {
            if (string.IsNullOrEmpty(path)) return;
            string full = Path.GetFullPath(path);

            RecentFiles.RemoveAll(p => p.Equals(full, StringComparison.OrdinalIgnoreCase));
            RecentFiles.Insert(0, full);

            if (RecentFiles.Count > 15)
            {
                RecentFiles.RemoveRange(15, RecentFiles.Count - 15);
            }
        }

        public static AppSettings Load()
        {
            try
            {
                if (File.Exists(SettingsFile))
                {
                    string json = File.ReadAllText(SettingsFile);
                    var settings = JsonSerializer.Deserialize<AppSettings>(json);
                    if (settings != null) return settings;
                }
            }
            catch
            {
                // Fallback to defaults
            }
            return new AppSettings();
        }

        private static readonly object _saveLock = new object();

        public void Save()
        {
            lock (_saveLock)
            {
                try
                {
                    if (!Directory.Exists(SettingsFolder))
                    {
                        Directory.CreateDirectory(SettingsFolder);
                    }
                    string json = JsonSerializer.Serialize(this, new JsonSerializerOptions { WriteIndented = true });
                    string tempFile = SettingsFile + ".tmp";
                    File.WriteAllText(tempFile, json);
                    File.Move(tempFile, SettingsFile, overwrite: true);
                }
                catch
                {
                    // Ignore save errors
                }
            }
        }
    }
}
